let bool = false;
export const loginBool = () => {
  bool = !bool;
  return bool;
};
