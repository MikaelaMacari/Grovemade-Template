let bool = false;
export const adminBool = () => {
  // const newBool  = bool;
  bool = !bool;
  return bool;
};
