let str = "";
export const loginPassword = (param) => {
  if (param) {
    str = param;
  }
  return str;
};
