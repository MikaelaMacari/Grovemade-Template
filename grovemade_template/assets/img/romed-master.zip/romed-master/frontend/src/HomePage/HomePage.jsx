import Footer from "../UI/Footer/Footer";
import Header from "../UI/Header/Header";
import "./HomePageStyles.css";
import CarouselApp from "./Carusel";
function HomePage() {
  return (
    //bgBody
    <div className="">
      <Header />
      <CarouselApp />
      <Footer />
    </div>
  );
}

export default HomePage;
